export const environment = {
  production: true,
  firebase : {
    apiKey: "AIzaSyB1U-wGTYzQlWKL96Ybxs8o0xem-R5v1pU",
    authDomain: "blackmonster71021.firebaseapp.com",
    projectId: "blackmonster71021",
    storageBucket: "blackmonster71021.appspot.com",
    messagingSenderId: "639507070776",
    appId: "1:639507070776:web:077f19304fc0eef63b4bcd",
    measurementId: "G-GP93HH2CTT"
  }
};
