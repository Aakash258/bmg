import { Component } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import emailjs, { EmailJSResponseStatus } from 'emailjs-com';
import { UserMgmtService } from '../service/user-mgmt.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})

export class RegisterComponent {

  registrationform = new FormGroup({
    firstname: new FormControl('', [Validators.required, Validators.pattern('[A-Za-z]+')]),
    lastname: new FormControl('', [Validators.required, Validators.pattern('[A-Za-z]+')]),
    age: new FormControl('', [Validators.required, Validators.pattern('[0-9]+')]),
    gender: new FormControl('', Validators.required),
    email: new FormControl('', [Validators.required, Validators.email]),
    phone: new FormControl('', [Validators.required, Validators.minLength(10), Validators.maxLength(10)]),
    plan: new FormControl('', Validators.required)
  })


  constructor(private userService: UserMgmtService) { }

  onRegister() {
    console.log(this.registrationform)
    this.userService.addMember(this.registrationform.value)
      .then(() => {
        alert('Member Added Successfully')
        this.sendEmail()

        this.registrationform.reset()
      })
  }

  public sendEmail() {
    // e.preventDefault();
    emailjs.send('registration_service', 'template_6ngqvlm',
      {
        firstname: this.registrationform.value.firstname,
        email: this.registrationform.value.email,
        phone: this.registrationform.value.phone
      }, 'user_mtPx6kjp6pkNpUTeh0MFz')
      .then((result: EmailJSResponseStatus) => {
        console.log(result.text);
      }, (error) => {
        console.log(error.text);
      });
  }

  paymentHandler:any = null;

 

  ngOnInit() {
    this.invokeStripe();
  }
  
  initializePayment(amount: number) {
    const paymentHandler = (<any>window).StripeCheckout.configure({
      key: 'pk_test_51KNVBiSFZt9V0txSluTARTDVgZeIpGbyStAGBxIoLrNDEvL9IG0pB4yrhehkcUjOG29zmORimurKfo1sDnfUsUWg00N2tnEb8R',
      locale: 'auto',
      token: function (stripeToken: any) {
        console.log({stripeToken})
        alert('Stripe token generated!');
      }
    });
  
    paymentHandler.open({
      name: 'FreakyJolly',
      description: 'Buying a Hot Coffee',
      amount: amount * 100
    });
  }
  
  invokeStripe() {
    if(!window.document.getElementById('stripe-script')) {
      const script = window.document.createElement("script");
      script.id = "stripe-script";
      script.type = "text/javascript";
      script.src = "https://checkout.stripe.com/checkout.js";
      script.onload = () => {
        this.paymentHandler = (<any>window).StripeCheckout.configure({
          key: 'pk_test_51KNVBiSFZt9V0txSluTARTDVgZeIpGbyStAGBxIoLrNDEvL9IG0pB4yrhehkcUjOG29zmORimurKfo1sDnfUsUWg00N2tnEb8R',
          locale: 'auto',
          token: function (stripeToken: any) {
            console.log(stripeToken)
            alert('Payment has been successfull!');
          }
        });
      }
      window.document.body.appendChild(script);
    }
  }

}
